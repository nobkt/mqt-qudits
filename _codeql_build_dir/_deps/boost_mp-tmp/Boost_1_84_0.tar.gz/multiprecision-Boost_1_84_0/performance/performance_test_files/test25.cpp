///////////////////////////////////////////////////////////////
//  Copyright 2019 John Maddock. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt

#include "../performance_test.hpp"
#if defined(TEST_TOMMATH)
#include <boost/multiprecision/tommath.hpp>
#endif

void test25()
{
#ifdef TEST_TOMMATH
   test<boost::multiprecision::tom_int>("tommath_int", 128);
#endif
}
